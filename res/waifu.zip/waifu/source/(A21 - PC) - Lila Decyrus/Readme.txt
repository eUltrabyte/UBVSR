Thank you for downloading


Assets where ripped from the Switch verson of Atelier Ryza (JPN). Ripped was thanks to Ploaj's tool, however edited quite a bit by me (Kuro).

Standard edits include merging meshes together to make a whole (like two halves of a face) and other slight changes caused by messy exports.

I have notice that the UV's are a little wonky. You should not need to worry about those. Its a product of an issue however proves to do nothing visually. Its still a problem
that I need to fix, and I will fix it if I can, which is why its not seen eveywhere.


If there is anything you "Need" To know, it would be listed below:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

